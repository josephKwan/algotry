# lendingclub_kmeans.R - Script for descriptive analysis of loans.csv data
# Copyright (c) 2021 by R. Ravi (ravi@cmu.edu) and Alan Montgomery (alanmontgomery@cmu.edu).
# Distributed under license CC BY-NC 4.0
# To view a copy of this license, https://creativecommons.org/licenses/by-nc/4.0/



##################################################################################
## @Setup any packages that are needed
##################################################################################

if (!require(corrplot)) {install.packages("corrplot"); library(corrplot)}
if (!require(gmodels)) {install.packages("gmodels"); library(gmodels)}
if (!require(gplots)) {install.packages("gplots"); library(gplots)}
if (!require(ggplot2)) {install.packages("ggplot2"); library(ggplot2)}
if (!require(lattice)) {install.packages("lattice"); library(lattice)}



##################################################################################
## @Input the data
##################################################################################

# !! edit the following line and uncomment
#setwd("~/Documents/class/data science/examples/lendingclub")
# Or Ensure that loans-kpi.csv is in the same directory as this R script
# Then use the Session menu item in RStudio to set working directory to source file location
# Read the loans data set saved in comma separated value format
loans.full <- read.csv("loans-kpi.csv")

# Display the structure of the object read in, and summarize its fields
str(loans.full)
summary(loans.full)



##################################################################################
## @Exploratory analysis: Descriptive statistics and graphics
##################################################################################

# This is a good place to make sure you understand what the different fields mean
# E.g., the fraction of defaulters in the data set can be computed by taking the mean
mean(loans.full$default)

# Single variable summary of continuous variables
boxplot(loans.full$fico,horizontal=TRUE,xlab="FICO")

# !!! Repeat the above for other interesting continuous variables

# Cross tabulate how the target variable and other categorical variables are related
xtabs(~credit.policy+default,data=loans.full)
xtabs(~purpose+default,data=loans.full)

# Simple histograms of the default variable versus categorical variables
# barplot is called on the table command which automatically bins the variable given to it 
# This first one shows the histograms of the defaulters
barplot(table(loans.full$default),
        main="Paid versus not paid loans",
        xlab="Status",
        border="black", 
        col=c("green","red"))

#... and how the defaulters varies with the second coordinate, the credit policy
barplot(table(loans.full$default, loans.full$credit.policy),
        main="Default Distribution by Credit Policy",
        xlab="Cust meets underwriting criteria",
        col=c("green","red"))

# !!!
# You can adapt the above command to visually represent the variation of defaulters with other categorical variables
#   like delinq.2yrs, loan purpose, inq.last.6mnths etc. that have few values represented

# Box-and-whisker plots to see dispersion of continuous vars across default and not default
# boxplot uses the formula syntax, with LHS being the y-var (vertical) and RHS being the x-variables (horizontal)
boxplot(loans.full$int.rate ~ loans.full$default,main="Interest Rates across Default")

# !!!
# You can adapt the above command to visually represent the variation of defaulters with other continuous variables
#   like installment, log.annual.inc, dti, fico, days with credit line, revolving credit balance and fraction of
#   revolving credit utilized

#compute correlation matrix among numerical attributes in one large matrix
# cor is the command for computing correlations, 3:14 indicate the column numbers 3 to 14 that have numerical 
# values and can be used to compute correlations
(correlations <- cor(loans.full[,3:14]))

# If you also want to include the first column which is numerical, you can concatenate the first row in the list
#  of columns using the c() command for concatenation
(correlations <- cor(loans.full[,c(1,3:14)]))

#Generate a heat map of correlated predictors
#  (the hclust parameter orders the rows and columns according to a hierarchical clustering method)
corrplot(correlations, order="hclust")



####################################################################################
## @kmeans clustering
####################################################################################

# variable list for clustering
varlist=c("credit.policy","int.rate","installment","log.annual.inc","dti","fico","days.with.cr.line","revol.bal","revol.util","inq.last.6mths","delinq.2yrs","pub.rec","default")  

# !!! Todo #1: Finalize the set of variables by examining the clusters against informative categorical variables
# Modify the variable list above to remove redundant variables that capture similar information, 
#  and others variables that may skew the clustering results in your opinion.

# Note from the correlation plot that fico, dti, int,rate and revol.util for a correlated group and
# log.annual.inc, installment revol.bal and days.with.cr.line another such group
# You could pick one from each group for the cluster analysis, and leave out credit.policy and default
#  since they are behaviors encoded after the fact of the loan application
varlist=c(
          "credit.policy",
          #"int.rate",
          #"installment",
          "log.annual.inc",
          "dti",
          "fico",
          #"days.with.cr.line",
          #"revol.bal",
          #"revol.util",
          "inq.last.6mths",
          "delinq.2yrs",
          "pub.rec"
          #"default",
          #"tot.paymnt",
          #"principal",
          #'interest'
          )  

# standardize the data that we wish to use in the cluster analysis
# e.g., mean=0 and std dev=1 for each variable
xloan = scale(loans.full[varlist])
#!! try it again without scaling the data by uncommenting this line
#xloan = loans.full[varlist]

### k-means cluster with k=3
(grpA=kmeans(xloan,centers=3))

# Examine how the clusters split the loans that obey the credit policy versus those that do not
#  Are your clusters helpful in predicting the credit.policy variable?
xtabs(~loans.full$credit.policy+grpA$cluster)

# !!! Todo #1
# Examine how the clusters split other categories to see if they correlate with the category
# E.g. by tabulating with default behavior, you can check if the clusters split loans into those
#  more or less prone to default.
xtabs(~loans.full$default+grpA$cluster)



###############################################################################
## @scree plot to determine how many clusters to use by creating kmeans solutions
## with k from 2 to 30 and then we can plot the sum of square errors to 
## understand how much variation each solution explains
###############################################################################

# compute multiple cluster solutions
set.seed(124895792)  # set the random number seed so the samples will be the same if regenerated
grpA2=kmeans(xloan[],centers=2,nstart=30)  # include nstart=30 as an option to evaluate 30 starting points and return best 
grpA3=kmeans(xloan[],centers=3,nstart=30)
grpA4=kmeans(xloan[],centers=4,nstart=30)
grpA5=kmeans(xloan[],centers=5,nstart=30)
grpA6=kmeans(xloan[],centers=6,nstart=30)
grpA7=kmeans(xloan[],centers=7,nstart=30)
grpA8=kmeans(xloan[],centers=8,nstart=30)
grpA9=kmeans(xloan[],centers=9,nstart=30)
grpA10=kmeans(xloan[],centers=10,nstart=30)
grpA15=kmeans(xloan[],centers=15,nstart=30)
grpA20=kmeans(xloan[],centers=20,nstart=30)
grpA30=kmeans(xloan[],centers=30,nstart=30)

# compute between and within SS
kclust=c(2:10,15,20,30)
bss=c(grpA2$betweenss,
      grpA3$betweenss,grpA4$betweenss,grpA5$betweenss,grpA6$betweenss,
      grpA7$betweenss,grpA8$betweenss,grpA9$betweenss,grpA10$betweenss,
      grpA15$betweenss,grpA20$betweenss,grpA30$betweenss)
wss=c(grpA2$tot.withinss,
      grpA3$tot.withinss,grpA4$tot.withinss,grpA5$tot.withinss,grpA6$tot.withinss,
      grpA7$tot.withinss,grpA8$tot.withinss,grpA9$tot.withinss,grpA10$tot.withinss,
      grpA15$tot.withinss,grpA20$tot.withinss,grpA30$tot.withinss)

# plot the results and look for the "Hockey-Stick" effect
par(mfrow=c(1,1))
plot(kclust,wss,type="l",main="Within SS for k-means")  # Within SS is variation of errors
points(kclust,wss)

# alternatively we can look at Between SS or R-Squared, notice Between+Within=Total, R-Squared=1-Within/Total,
# Total does not change with k.  The difference is the these graphs go up with fit.
plot(kclust,bss,type="l",main="Between SS for k-means") # Between SS is variation of predictions
points(kclust,bss)
plot(kclust,bss/(wss+bss),type="l",main="R-Squared for k-means")  # R-Squared is ratio of explained variation
points(kclust,bss/(wss+bss))



###############################################################################
### @Cluster analysis
### Notice that the large number of variables may make interpretation difficult
###############################################################################

# !!! Todo#2: set your k value 
k=7

# compute a k-means cluster with k 
set.seed(1248765792)  # set the random number seed so the samples will be the same if regenerated
(grpB=kmeans(xloan,centers=k))

# !!! Todo#3: choose your cluster names !!,  update these after you have summarized the clusters below
knames=as.character(1:k)  # default is just name them 1, 2, ...
#knames=c("1","2","3")    # edit the string, make sure you have one label for each kvalue

# plot the solutions against the credit.policy and inquiries in last 6 mos
# since the data is categorical most of the plots will overlay one another,
# so instead we jitter the points -- which adds a small random number to each
par(mfrow=c(1,1),mar=c(5,4,4,1)+.1)
plot(jitter(xloan[,"credit.policy"]), jitter(xloan[,"inq.last.6mths"]),xlab="cr.pol",ylab="inq6m",col=grpB$cluster)
points(grpB$centers[,c("credit.policy","inq.last.6mths")],col=1:k,pch=8,cex=2)
legend("topright",pch=8,bty="n",col=1:k,knames)

# !!! Todo#3: try different variables instead of these two 
plot(xloan[,"fico"],(xloan[,"dti"]),xlab="fico",ylab="dti",col=grpB$cluster)
points(grpB$centers[,c("fico","dti")],col=1:k,pch=8,cex=2)
legend("topleft",pch=8,bty="n",col=1:k,knames)

# compare the cluster solutions with loan purpose
(result = xtabs(~loans.full$purpose+grpB$cluster) )  # xtabs using formula notation unlike table

# slightly nicer cross tabulation
CrossTable(loans.full$purpose,grpB$cluster)  

# Here is a more visual representation of a table with a BalloonPlot
par(mfrow=c(1,1))  # reset to one plot in panel
balloonplot(result)

# summarize the centroids
round(grpB$centers,2)   # print the centroid values for each variable
# create a parallel plot to visualize the centroid values (scales cex changes the size of text font)
parallelplot(grpB$centers,varnames=varlist,auto.key=list(text=knames,space="top",columns=1,lines=T),scales=list(cex=.5))

# a parallel plot with just a few variables, since the previous plot is quite dense; 
# !!! Todo #3: Try different lists of variables 
# Use the separation of the cluster centers among your chosen variables to "name" these clusters
shortvarlist=c("fico","dti","log.annual.inc")   # short list of variables, note: add variables if you like
round(grpB$centers[,shortvarlist],2)
parallelplot(grpB$centers[,shortvarlist],varnames=shortvarlist,auto.key=list(text=knames,space="top",columns=3,lines=T))
# let's do a pairwise plot with the short list of variables
pairs(sapply(loans.full[shortvarlist],jitter,amount=.2),col=grpB$cluster)

# to save the data to CSV files, useful for importing into Excel for analysis
write.csv(grpB$cluster,file="Loans_ResultsBcluster.csv")  # cluster assignments
write.csv(grpB$centers,file="Loans_ResultsBcenters.csv")  # cluster centroids


