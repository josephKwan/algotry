
#
# example to create a logistic regression to predict heart disease
#

# input data
setwd("~/Documents/class/data science/examples/lecture05")
disease = read.csv("heart_disease.csv")

# plot data
plot(disease$age,disease$cd,pch=16,xlab="Age",ylab="Diseased (1=Yes,0=No)")

# discretized version
decade=floor(disease$age/10)
propdecade=aggregate(disease$cd,by=list(decade=decade),mean)
plot(propdecade$decade,propdecade$x,pch=16,xlab="Age group (Decade)",ylab="Diseased %")

# table of risks
table(disease$cd,disease$age>=50,dnn=c("Disease","Age>=50"))

# estimate logistic regression
lmodel=glm(cd~age,data=disease,family="binomial")
summary(lmodel)

# predict using the model
lpredict=predict(lmodel,type='response')
guess=(lpredict>.5)+0    # add the 0 to have R make this a number

# plot data and overlay predicted probabilities
plot(disease$age,disease$cd)
points(disease$age,lpredict,pch=16,cex=.5)
lines(disease$age,lpredict)

# compare the guesses to the actual
xtabs(~guess+disease$cd)

# compute ROC and AUC
if (!require(ROCR)) {install.packages("ROCR"); library(ROCR)}
rocpred = prediction(lpredict,disease$cd)  # compute predictions using "prediction"
rocperf = performance(rocpred, measure = "tpr", x.measure = "fpr")
plot(rocperf, col=rainbow(10)); abline(a=0, b= 1)
auc.tmp = performance(rocpred.lr,"auc")  # compute area under curve
(auc.lr = as.numeric(auc.tmp@y.values))

