
#
# example to create a logistic regression to predict heart disease
#

# input data
setwd("~/Documents/class/data science/examples/lecture06")
disease = read.csv("heart_disease.csv")

# plot data
plot(disease$age,disease$cd)

# estimate logistic regression
lmodel=glm(cd~age,data=disease,family="binomial")
summary(lmodel)

# predict using the model
lpredict=predict(lmodel,type='response')
guess=(lpredict>.5)+0    # add the 0 to have R make this a number

# compare the guesses to the actual
xtabs(~guess+disease$cd)



### (optional)  draw ROC curve

# install the ROCR library
if (!require(ROCR)) {install.packages("ROCR"); library(ROCR)}

# three commands for drawing ROC curve using ROCR
pred = prediction(lpredict,disease$cd)  # compute predictions using "prediction"
perf = performance(pred, measure = "tpr", x.measure = "fpr")
plot(perf, col=rainbow(10))
abline(a=0, b= 1)

# command to compute AUROC using ROCR
auc.tmp = performance(pred,"auc")
(auc = as.numeric(auc.tmp@y.values))

