###############################################################################
# Script: FordKa_Model.R
# Copyright (c) 2019 by Alan Montgomery. Distributed using license CC BY-NC 4.0
# To view this license see https://creativecommons.org/licenses/by-nc/4.0/
#
# R script to create customer segments for ford ka using supervised methods
# Requires the CSV files data to be in the current working directory.
# This script creates a k-means cluster using the demographic data.
###############################################################################



###############################################################################
### @setup the environment
###############################################################################

# setup environment 
if (!require(psych)) {install.packages("psych"); library(psych)}
if (!require(lattice)) {install.packages("lattice"); library(lattice)}
# create ROC curves
if (!require(gplots)) {install.packages("gplots"); library(gplots)}
if (!require(ROCR)) {install.packages("ROCR"); library(ROCR)}

# define a function to summary a classification matrix we will use later
confmatrix.summary <- function(predprob,predclass,trueclass) {
  # compute confusion matrix (columns have truth, rows have predictions)
  results = xtabs(~predclass+trueclass)  
  # compute usual metrics from the confusion matrix
  accuracy = (results[1,1]+results[2,2])/sum(results)   # how many correct guesses along the diagonal
  truepos = results[2,2]/(results[1,2]+results[2,2])  # how many correct "churn" guesses
  precision = results[2,2]/(results[2,1]+results[2,2]) # proportion of correct positive guesses 
  trueneg = results[1,1]/(results[2,1]+results[1,1])  # how many correct "non-churn" guesses 
  # compute the lift using the predictions for the 10% of most likely
  topchurn = as.vector( predprob >= as.numeric(quantile(predprob,probs=.9)))  # which customers are most likely to churn
  ( baseconv=sum(trueclass==1)/length(trueclass) )  # what proportion would we have expected purely due to chance
  ( actconv=sum(trueclass[topchurn])/sum(topchurn))  # what proportion did we actually predict
  ( lift=actconv/baseconv )  # what is the ratio of how many we got to what we expected
  return(list(confmatrix=results,accuracy=accuracy,truepos=truepos,precision=precision,trueneg=trueneg,lift=lift))
}



###############################################################################
### @input data
###############################################################################

# set the working directory manually
setwd("~/Documents/class/marketing analytics/cases/ford ka/data") #!! set to your directory

# read in the Ford Ka datasets from CSV files
forddemo=read.csv("FordKaDemographicData.csv",row.names=1)  # just the demographic data
fordpsyc=read.csv("FordKaPsychographicData.csv",row.names=1)  # just the psychographic data
fordquest=scan("FordKaQuestions.txt",what='a',sep='\n')  # question list, which is read as a vector
fordseg=read.csv("FordKaSegmentData.csv")  # these are the segments that Ford came up with

# create some lists of variables which we will use later in the script
qlist=paste0("Q",1:62)  # create vector of psychographic variables ("Q1", ..., "Q62")
names(fordquest)=qlist  # label the questions so we can extract fordquest["Q1"] or fordquest[1]
qdlist=c("Age","ChildrenCategory","FirstTimePurchase","Gender","IncomeCategory","MaritalStatus","NumberChildren")  # demographic variables

# create combined dataset with demographics and psychographics
ford=cbind(forddemo,fordpsyc)  # create a new dataframe with both demogrpahic and psychographic data
# create new standardized dataset using the scale function (set the mean of the new variable to 0 and stddev to 1)
xford=scale(ford)
xforddemo=scale(forddemo)   # not used in this script but created for compatability with Part1

# (optional) recode the values
#ford$PreferenceGroup = mapvalues(ford$PreferenceGroup,from=c(1,2,3),to=c("HighPref","LowPref","MedPref"))

# create factorized versions of the data
nford=ford
#nford$StrongPref = (ford$PreferenceGroup==1)   # this is our target: Is the consumer interested in Ka (Preference Group #1)
nford$KaPref = (ford$PreferenceGroup!=2)   # this is our target: Is the consumer interested in Ka (Preference Group #1 or #3)
nford$PreferenceGroup = NULL    # we are using KaPref as target, so remove original copy
nford$Gender = as.factor(ford$Gender)
nford$MaritalStatus = as.factor(ford$MaritalStatus)
nford$AgeCategory = NULL     # this is redundant with Age
nford$ChildrenCategory = as.factor(ford$ChildrenCategory)
nford$IncomeCategory = as.factor(ford$IncomeCategory)
nford$FirstTimePurchase = as.factor(ford$FirstTimePurchase)
str(nford)
xtabs(~nford$KaPref)  # check our new target
cutoff=mean(nford$KaPref)  # compute cutoff as average of those with Strong Preference
#cutoff=0.5

# prepare new values using a uniform random number, each record has 
# a corresponding uniform random value which will be used to decide if the observation
# is assigned to the training or validation sample
nobs=nrow(ford)
set.seed(1248765792)  # set the random number seed so the samples will be the same if regenerated
sample.obs=sample.int(nobs,200)   # indices that correspond to random sample
trainsample=(1:nobs %in% sample.obs)   # indicator for observations in training sample
validsample=!trainsample  # indicator for remaining observations in validation sample



###############################################################################
## @cluster: for reference compute the kmeans cluster with k=4
###############################################################################

### k-means cluster with k=4 using just the psychographics
(grpA=kmeans(xford[,qlist],centers=4))
xtabs(~nford$KaPref+grpA$cluster)   # compare decision tree with cluster solution
xtabs(~fordseg$SegName+grpA$cluster)

### compute cluster of questions
# transpose the data (columns become rows and rows become columns)
qford=t(ford[,qlist])
# compute a "best" solution
set.seed(612490)   # make sure we get the same solution
kQ=6
(grpQ=kmeans(qford,kQ,nstart=100))
# !! set your cluster names !!
kqnames=c("Relationship","SmallCarPrefer","Trendy","SmallCarForWomen","Practical","Character")  # 52,40,2,27,4,17

# using the cluster solution create a dataset with the average of the question "scores" for each cluster of questions
rford=t(grpQ$centers)
colnames(rford)=kqnames
rford=as.data.frame(rford)

# add the preference variable
rford$KaPref=nford$KaPref



###############################################################################
### @model_logistic: create logistic regression model
###############################################################################

## specify large model
#lrmdlD=glm(KaPref~FirstTimePurchase+Gender+Age+Q3+Q7+Q12+Q29+Q47+Q57,data=nford[trainsample,],family='binomial')
#summary(lrmdlD)

## use forward stepwise to specify logistic regression
# first estimate the null model (this just has an intercept)
null=glm(KaPref~1,data=nford[trainsample,],family='binomial')
# second estimate a complete model (with all variables that you are interested in)
full=glm(KaPref~.,data=nford[trainsample,],family='binomial')
# finally estimate the step wise regression starting with the null model
#lrmdlS=step(null,scope=formula(full),dir="forward")  # !! default value of steps !!
lrmdlS=step(null,scope=formula(full),steps=5,dir="forward")  # !! can increase steps, but careful not to overfit !!
# give a summary of the model's trained parameters
summary(lrmdlS)

# list the questions used in the tree
as.vector(fordquest[c(12,40,44,46,49)])

# compute predictions for the entire sample -- but model was only trained on trainsample
lrmdl=lrmdlS  # set this line to whichever logistic regression model you want to use
ppref.lr = predict(lrmdl,newdata=nford,type='response')  # create probability predictions from model
cpref.lr = (ppref.lr>cutoff)+0  # classify predictions using probability cutoff
truepref = nford$KaPref  # get actual preferences

# summarize results by computing confusion matrix
# for the training sample
(results = table(cpref.lr[trainsample],truepref[trainsample],dnn=c("True","Predict")))
(accuracy = (results[1,1]+results[2,2])/sum(results))  
(truepos = (results[2,2]/(results[1,2]+results[2,2])))
# for the validation sample
(results = table(cpref.lr[validsample],truepref[validsample],dnn=c("True","Predict")))
(accuracy = (results[1,1]+results[2,2])/sum(results))  
(truepos = (results[2,2]/(results[1,2]+results[2,2])))

# compute confusion matrix and some usual statistics (uncomment train and prediction samples if you want to see these statistics)
confmatrix.summary(ppref.lr[trainsample],cpref.lr[trainsample],truepref[trainsample])  # summary for training sample (look to see if train is substantially better than valid)
confmatrix.summary(ppref.lr[validsample],cpref.lr[validsample],truepref[validsample])  # summary for validation sample

# compute ROC and AUC
rocpred.lr = prediction(ppref.lr[validsample],nford$KaPref[validsample])  # compute predictions using "prediction"
rocperf.lr = performance(rocpred.lr, measure = "tpr", x.measure = "fpr")
plot(rocperf.lr, col=rainbow(10)); abline(a=0, b= 1)
auc.tmp = performance(rocpred.lr,"auc")  # compute area under curve
(auc.lr = as.numeric(auc.tmp@y.values))

# compare the logistic regression classifications against the ford segments
(results = xtabs(~cpref.lr+ford$PreferenceGroup) )  # confusion matrix compare preference with predictions
(results = xtabs(~cpref.lr+nford$KaPref) )  # confusion matrix compare preference with predictions
(results = xtabs(~cpref.lr+fordseg$SegName) )  # confusion matrix compare predictions with segments

