###############################################################################
# Script: Movie_PrepData.R
# Not for distribution
###############################################################################


#setup
require(stringr)
require(slam)
require(tm)


##################### input the data  ######################

## read in the data

# set to your correct working directory
setwd("~/Documents/class/data science/examples/movies")

# read in movie datasets
movies=read.delim("opus_movies.txt",header=T,stringsAsFactors=FALSE)  # the Opus movie data
movies$odid=factor(movies$odid)
movies$short_name=str_trim(strtrim(enc2native(as.character(movies$display_name)),22))
dupnames=movies$short_name[duplicated(movies$short_name)]
isdup=movies$short_name %in% dupnames
movies$short_name[isdup]=paste0(movies$short_name[isdup]," (",movies$production_year[isdup],")")  # append production year for duplicated short names

# read in tags
tags=read.delim("opus_movielens_tags.txt",header=T)  # just the tags from movielens
tags$odid=as.factor(tags$odid)

# keep only select fields from movies
movies=movies[movies$odid %in% unique(tags$odid),c("odid","display_name","short_name","domestic_box_office","genre","production_year","release_date")]
#movies$short_name=as.factor(movies$short_name)


## transform the terms into a structure that can be used for topic modeling

# use this definition of mterms for movielens tags
# put data in sparse matrix form using simple_triplet_matrix as needed by LDA
mterms=simple_triplet_matrix(i=as.integer(tags$odid),j=as.integer(tags$tag),v=tags$count,
                             dimnames=list(movies$short_name,levels(tags$tag)))
# version using odid
#mterms=simple_triplet_matrix(i=as.integer(tags$odid),j=as.integer(tags$tag),v=tags$count,
#                             dimnames=list(levels(tags$odid),levels(tags$tag)))
# let's only keep words that are used frequently (by at least 20 movies)
mterms=mterms[,apply(mterms,2,sum)>=20]
# also delete any movies that do not have any terms
mterms=mterms[apply(mterms,1,sum)>0,]
# check dimensions
lmterms=apply(mterms,1,sum)   # compute the sum of each of the rows (# of terms per movie)
lwterms=apply(mterms,2,sum)   # compute the sum of each of the columns (# of times word used)

# determine dimensions of mterms
moviedata=movies[movies$short_name %in% rownames(mterms),]   # create a subset of the movies that have terms

# also create another version as DocumentTermMatrix
movietags = as.DocumentTermMatrix(mterms,weight=weightTf)

# save the moviedata and movietags to a dataset
save(moviedata,movietags,file="Movie_Data.RData")



